##Вступление##

Сначала извинюсь, <a href="https://habrahabr.ru/post/275605/">тут</a> малость сыро, хотя и работает, а сейчас работает "влет", но без телефонии  возможности  ограничены. В основном был описан вариант для разработки, когда  основной каталог $OPENSHIFT_REPO_DIR (~/app-root/repo) и Вы в своем локальном репозитории имеете копию, делаете правки, OpenShift - это Ваша песочница. 
Но есть вариант установки "для эксплуатации". Он упомянут в конце вышеуказанной статьи, но без деталей. В этом случае Вы используете $OPENSHIFT_DATA_DIR (~/app-root/data). Разница в том, что локальный репозиторий содержит настроечные скрипты (action_hooks, см. ниже) и файлы данных, патчи, etc. Но не само приложение целиком. 

Мини-руководство иллюстрирует ряд приемов работы  с OpenShift. Работа с github.com, git детально не разбирается, предполагается, что читатель уже имеет представление. 

1. Создание и клонирование на OpenShift заготовки.
2. Редактирование скриптов развертывания для получения годного установочного комплекта.
3. Запись репозитория на github.com (для хранения). 
4. Развертывание приложения на OpenShift.

Руководство "step-by-step", основанное на реальном примере.

##Перед началом##

Установка на любой PaaS-хостинг(тот же [Redhat Openshift](http://openshift.redhat.com)) требует, соблюдения его спецификаций:

Регистрация:  <a href="https://www.openshift.com/app/account/new">здесь</a>
Установка клиента: <a href="https://developers.openshift.com/en/getting-started-overview.html">здесь (Вы уже зарегистрированы), там же и документация, но на вся English</a>
Не беспокойтесь об ОС работает почти везде одинаково. Да и Ваше приложение, как ни крути  под RHEL 6.7.
Предложат создать домен (это поддомен 3-го уровня, ваши приложения будут иметь адрес http://myapp-mydom.rhcloud.com).

Openshift глобально предоставит Вам каталог пользователя со стандартным набором подкаталогов:  <a href="https://habrahabr.ru/post/275605/">тут</a>. Особенность движка - в самом домашнем каталоге конфиги установленного ПО принадлежат root. Ваше имя длинная такая цифирь типа хэша (очень [docker](https://www.docker.com/) напоминает) .


Все необходимые данные хранятся в переменных окружения вида OPENSHIFT_, [справочник](https://developers.openshift.com/en/managing-environment-variables.html).




##Приступаем##

*Мы уже сделали*

* Создали учетную запись на https://openshift.redhat.com
* Поставили git, ruby, rhc.
* Запустили
  `$rhc setup`
И ответили на все вопросы. Будет произведен обмен ключами и подсоединение к домену OpenShift. 

Примечания:
> Приложение SalesPlatform-6.4.0, самоустанавливающийся LAMP. 
> Система CentOS 7.2 (но разница в деталях).
> мое приложение example, Ваше - на Ваше усмотрение. (В имени могут быть только латинские буквы и цифры).
> мой репозиторий на github.com https://github.com/zirf0/example, подсматривайте, если что.

1. Создаем "заглушку" и клонируем ее в свой домашний каталог.
  `$rhc app create example php-5.3 mysql-5.5`
  `$cd example`

2. Служебный каталог Openshift 
$ tree .openshift/
.openshift/
├── action_hooks
│   └── README.md
├── cron
│   ...
├── markers
│   └── README.md
├── pear.txt
└── README.md

Строго говоря нас интересуют [action_hooks](https://developers.openshift.com/en/managing-action-hooks.html). Это набор скриптов для различных целей, но для нашего примера мы используем только *build* и *deploy*, вообще имена скриптов соответствуют производимому действию. Будем решать простенькую задачу:


1. Выкачать исходники на PaaS-хостинг.
2. Развернуть их в ~/app-root/data/current
3. Внести изменения (как правило, обязательно заменить переменные доступа к СУБД на встроенные OpenShift).
4. Развернуть приложение.

3. Начнем

`$ vi .openshift/action_hooks/build`

И поместим туда
<spoiler title="build - скрипт начальной установки">
`#!/bin/bash`
`# в ~/app-root/data подкаталог current`
`#`
`current_version_dir=${OPENSHIFT_DATA_DIR}current`
`# Если существует, выходим.`
`[ -d "${current_version_dir}" ] && exit 0`
`# Версия для установки`
`install_version='6.4.0-201512'`
`# Создаем рабочие каталоги.`
`install_dir=${OPENSHIFT_BUILD_DEPENDENCIES_DIR}${install_version}`
`mkdir -p $install_dir`
`# Сохраним директорию`
`pushd ${install_dir} >/dev/null`
`# Выкачиваем установочный комплект (замените на свой).`
`curl -Ls downloads.sourceforge.net/project/salesplatform/salesplatform-vtigercrm-${install_version}.tar.gz > salesplatform-vtigercrm-${install_version}.tar.gz`
`# Разворачиваем архив`
`tar --strip-components=1 -xzf salesplatform-vtigercrm-${install_version}.tar.gz`
`# Удаляем архив, он уже не нужен.`
`rm -rf salesplatform-vtigercrm-${install_version}.tar.gz`
`# Для информативности`
`echo $install_version > ${OPENSHIFT_BUILD_DEPENDENCIES_DIR}.current_version`
`# Возвращаемся в сохраненный каталог.`
`popd >/dev/null`
</spoiler>

`$ vi .openshift/action_hooks/deploy`

В скрипте накладывается патч (та самая подстановка переменных среды для подключения к СУБД MySQL) и добавляется установочный .htaccess.  У вас могут быть свои, то есть дя примера возьмите [готовые](https://github.com/zirf0/example/tree/master/.openshift/config).  

<spoiler title="deploy - скрипт развертывания">
`#!/bin/bash`
`# This deploy hook gets executed after dependencies are resolved and the`
`# build hook has been run but before the application has been started back`
`# up again.  This script gets executed directly, so it could be python, php,`
`# ruby, etc.`
`dest_dir=${OPENSHIFT_DATA_DIR}current`
`current_version=$(cat ${OPENSHIFT_BUILD_DEPENDENCIES_DIR}.current_version)`
`install_dir=${OPENSHIFT_BUILD_DEPENDENCIES_DIR}${current_version}`
`if [ ! -d "${dest_dir}" ]; then`
`  mkdir -p $dest_dir`
`  cp -rf ${install_dir}/* ${dest_dir}/`
`fi`
`# Родной ~/app-root/repo/php удаляем (это ссылка на приложение php) и заменяем своей.`
`if [ -d ${OPENSHIFT_REPO_DIR}php ]; then`
`  rm -rf ${OPENSHIFT_REPO_DIR}php`
`fi`
`ln -sf ${dest_dir} ${OPENSHIFT_REPO_DIR}php`
`# Вставляем правильный .htaccess из .openshift/config `
`if [  -f ${OPENSHIFT_REPO_DIR}.openshift/config/.htaccess ]; then`
`  cp -f ${OPENSHIFT_REPO_DIR}.openshift/config/.htaccess ${dest_dir}/.htaccess`
`fi`
`set -e`
`# Патч. Как раз подставляет переменные среды для подключения к СУБД `
`  patch ${dest_dir}/modules/Install/views/Index.php    ${OPENSHIFT_REPO_DIR}.openshift/config/patches/db_conf.patch `
</spoiler>

Идем дальше. Создаем репозиторий на github.com.
В нашем каталоге:
`$git rm index.php`
`$vi README.md`
Естественно, файл нужно заполнить, нет ничего хуже репозитория, где на самом видном месте дырка от бублика.
`git add .`
`git commit -m "Initialize"`
Добавим github.com к удаленным репозиториям (естественно URL будет Ваш):
`$git remote add upstream ssh://git@github.com/zirf0/example.git `
Ключ ssh у нас уже есть ~/.ssh/id_rsa.pub. Добавьте его согласно [инструкции](https://help.github.com/articles/adding-a-new-ssh-key-to-your-github-account/) на github.com.

Заливаем наши труды на github.com
`$git push upstream master `

Развертываем приложение на PaaS Openshift^
`$git push`
Что эквивалентно *$git push origin master*.

<spoiler title="Должны получить что-то такое">
`Counting objects: 5, done.`
`Delta compression using up to 4 threads.`
`Compressing objects: 100% (3/3), done.`
`Writing objects: 100% (3/3), 339 bytes | 0 bytes/s, done.`
`Total 3 (delta 1), reused 0 (delta 0)`
`remote: Stopping PHP 5.3 cartridge (Apache+mod_php)`
`remote: Stopping MySQL 5.5 cartridge`
`remote: Building git ref 'master', commit 38fe1a5`
`remote: Checking .openshift/pear.txt for PEAR dependency...`
`remote: Preparing build for deployment`
`remote: Deployment id is b4269d37`
`remote: Activating deployment`
`remote: Starting MySQL 5.5 cartridge`
`remote: patching file /var/lib/openshift/56c4641789f5cfbebb000031/app-root/data/current/modules/Install/views/Index.php`
`remote: Hunk #1 succeeded at 98 with fuzz 1.`
`remote: Starting PHP 5.3 cartridge (Apache+mod_php)`
`remote: Application directory "php/" selected as DocumentRoot`
`remote: -------------------------`
`remote: Git Post-Receive Result: success`
`remote: Activation status: success`
`remote: Deployment completed with status: success`
`To ssh://56c4641789f5cfbebb000031@example-helidon.rhcloud.com/~/git/example.git/`
 `  f5b094a..38fe1a5  master -> master`
</spoiler>

Все, через web должна запуститься установка.

** Пожелания, предложения?**
